# lottery-android
A lottery data analysis app built with Kotlin, MVVM, Hilt, Room and MPAndroidChart
